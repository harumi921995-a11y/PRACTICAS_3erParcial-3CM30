#include <iostream>
#include <cstdlib> // Necesaria para limpiar 
#include "cola.h"

using namespace std;

int main() {
    Cola miCola;
    int opcion, numero;

    do {
        system("cls"); // Borra la pantalla antes de mostrar el menu        
        cout << "       MENU DE COLA     " << endl;
        cout << "----------------------------------------" << endl;
        cout << "1. Agregar elemento (Enqueue)" << endl;
        cout << "2. Quitar elemento (Dequeue)" << endl;
        cout << "3. Mostrar cola" << endl;
        cout << "4. Verificar si esta vacia" << endl;
        cout << "5. Verificar si esta llena" << endl;
        cout << "6. Mostrar tamano de la cola" << endl;
        cout << "7. Guardar en archivos (TXT, CSV, XML, JSON)" << endl;
        cout << "8. Salir" << endl;
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        switch (opcion) {
            case 1:
                cout << "Ingrese el numero: ";
                cin >> numero;
                miCola.agregar(numero);
                system("pause"); 
                break;

            case 2:
                numero = miCola.quitar();
                if (numero != -1) {
                    cout << "\n[-] Elemento " << numero << " removido de la fila." << endl;
                }
                system("pause");
                break;

            case 3:
                miCola.visualizar();
                system("pause");
                break;

            case 4:
                if (miCola.estaVacia()) cout << "\nLa cola esta vacia." << endl;
                else cout << "\nLa cola contiene elementos esperando." << endl;
                system("pause");
                break;

            case 5:
                if (miCola.estaLlena()) cout << "\nLa cola esta llena al limite maximo." << endl;
                else cout << "\nLa cola aun tiene espacio disponible." << endl;
                system("pause");
                break;

            case 6:
                cout << "\nTamano actual de la fila: " << miCola.obtenerTamano() << " elementos." << endl;
                system("pause");
                break;

            case 7:
                cout << "\n--- Exportando el estado actual de la cola circular ---" << endl;
                miCola.guardarTXT("cola_reporte.txt");
                miCola.guardarCSV("cola_reporte.csv");
                miCola.guardarXML("cola_reporte.xml");
                miCola.guardarJSON("cola_reporte.json");
                system("pause");
                break;

            case 8:
                cout << "\nSaliendo del programa..." << endl;
                break;

            default:
                cout << "\nOpcion no valida. Intente de nuevo." << endl;
                system("pause");
        }
    } while (opcion != 8);

    return 0;
}