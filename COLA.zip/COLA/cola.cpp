#include "cola.h"
#include <iostream>
#include <fstream>

using namespace std;

Cola::Cola() {
    frente = 0;
    final = -1;
    contador = 0;
}

Cola::~Cola() {}

bool Cola::estaVacia() {
    return (contador == 0);
}

bool Cola::estaLlena() {
    return (contador == MAX);
}

void Cola::agregar(int v) {
    if (estaLlena()) {
        cout << "\n[!] Error: La cola esta llena." << endl;
    } else {
        final = (final + 1) % MAX; 
        datos[final] = v;
        contador++;
        cout << "\n[+] Elemento " << v << " agregado a la fila." << endl;
    }
}

int Cola::quitar() {
    if (estaVacia()) {
        cout << "\n[!] Error: La cola esta vacia." << endl;
        return -1;
    } else {
        int valor = datos[frente];
        frente = (frente + 1) % MAX; 
        contador--;
        return valor;
    }
}

void Cola::visualizar() {
    if (estaVacia()) {
        cout << "\nLa cola no tiene elementos." << endl;
    } else {
        cout << "\n--- ELEMENTOS EN LA COLA ---" << endl;
        int aux = frente;
        for (int i = 0; i < contador; i++) {
            cout << "[" << datos[aux] << "] ";
            aux = (aux + 1) % MAX;
        }
        cout << "\n---------------------------" << endl;
    }
}

int Cola::obtenerTamano() {
    return contador;
}

// =================================================================
// IMPLEMENTACIÓN DE GUARDADO EN ARCHIVOS 
// =================================================================

void Cola::guardarTXT(const string& nombreArchivo) {
    ofstream archivo(nombreArchivo);
    if (archivo.is_open()) {
        archivo << "=== ESTADO ACTUAL DE LA COLA ===\n";
        archivo << "Elementos actuales: " << contador << " / " << MAX << "\n\n";
        
        int aux = frente;
        for (int i = 0; i < contador; i++) {
            archivo << "Turno [" << i + 1 << "] -> Valor: " << datos[aux];
            if (aux == frente) archivo << " (FRENTE)";
            if (aux == final) archivo << " (FINAL)";
            archivo << "\n";
            aux = (aux + 1) % MAX;
        }
        archivo.close();
        cout << "[OK] Archivo TXT guardado correctamente." << endl;
    } else {
        cout << "[ERROR] No se pudo crear el archivo TXT." << endl;
    }
}

void Cola::guardarCSV(const string& nombreArchivo) {
    ofstream archivo(nombreArchivo);
    if (archivo.is_open()) {
        archivo << "Turno,Valor,Ubicacion\n";
        int aux = frente;
        for (int i = 0; i < contador; i++) {
            string ubicacion = "-";
            if (aux == frente && aux == final) ubicacion = "FRENTE_Y_FINAL";
            else if (aux == frente) ubicacion = "FRENTE";
            else if (aux == final) ubicacion = "FINAL";

            archivo << (i + 1) << "," << datos[aux] << "," << ubicacion << "\n";
            aux = (aux + 1) % MAX;
        }
        archivo.close();
        cout << "[OK] Archivo CSV guardado correctamente." << endl;
    } else {
        cout << "[ERROR] No se pudo crear el archivo CSV." << endl;
    }
}

void Cola::guardarXML(const string& nombreArchivo) {
    ofstream archivo(nombreArchivo);
    if (archivo.is_open()) {
        archivo << "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
        archivo << "<cola>\n";
        archivo << "    <contador>" << contador << "</contador>\n";
        archivo << "    <capacidad_maxima>" << MAX << "</capacidad_maxima>\n";
        archivo << "    <elementos>\n";
        
        int aux = frente;
        for (int i = 0; i < contador; i++) {
            archivo << "        <elemento>\n";
            archivo << "            <turno>" << (i + 1) << "</turno>\n";
            archivo << "            <valor>" << datos[aux] << "</valor>\n";
            archivo << "            <es_frente>" << (aux == frente ? "true" : "false") << "</es_frente>\n";
            archivo << "            <es_final>" << (aux == final ? "true" : "false") << "</es_final>\n";
            archivo << "        </elemento>\n";
            aux = (aux + 1) % MAX;
        }
        archivo << "    </elementos>\n";
        archivo << "</cola>\n";
        archivo.close();
        cout << "[OK] Archivo XML guardado correctamente." << endl;
    } else {
        cout << "[ERROR] No se pudo crear el archivo XML." << endl;
    }
}

void Cola::guardarJSON(const string& nombreArchivo) {
    ofstream archivo(nombreArchivo);
    if (archivo.is_open()) {
        archivo << "{\n";
        archivo << "  \"contador\": " << contador << ",\n";
        archivo << "  \"capacidad_maxima\": " << MAX << ",\n";
        archivo << "  \"elementos\": [\n";
        
        int aux = frente;
        for (int i = 0; i < contador; i++) {
            archivo << "    {\n";
            archivo << "      \"turno\": " << (i + 1) << ",\n";
            archivo << "      \"valor\": " << datos[aux] << ",\n";
            archivo << "      \"es_frente\": " << (aux == frente ? "true" : "false") << ",\n";
            archivo << "      \"es_final\": " << (aux == final ? "true" : "false") << "\n";
            archivo << "    }";
            
            aux = (aux + 1) % MAX;
            if (i < contador - 1) archivo << ",\n";
            else archivo << "\n";
        }
        archivo << "  ]\n";
        archivo << "}\n";
        archivo.close();
        cout << "[OK] Archivo JSON guardado correctamente." << endl;
    } else {
        cout << "[ERROR] No se pudo crear el archivo JSON." << endl;
    }
}