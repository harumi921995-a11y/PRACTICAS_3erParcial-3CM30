#ifndef COLA_H
#define COLA_H

#include <string>

const int MAX = 10; // Tamaño máximo del arreglo

class Cola {
private:
    int datos[MAX];
    int frente;
    int final;
    int contador;

public:
    Cola();
    ~Cola();
    
    bool estaVacia();    // Para opcion 4
    bool estaLlena();    // Para opcion 5
    void agregar(int v); // Para opcion 1
    int quitar();        // Para opcion 2
    void visualizar();   // Para opcion 3
    int obtenerTamano(); // Para opcion 6

    // ---- NUEVOS MÉTODOS DE EXPORTACIÓN ----
    void guardarTXT(const std::string& nombreArchivo);
    void guardarCSV(const std::string& nombreArchivo);
    void guardarXML(const std::string& nombreArchivo);
    void guardarJSON(const std::string& nombreArchivo);
};

#endif