#include "lista.h"
#include <iostream>
#include <fstream>

using namespace std;

Lista::Lista() {
    cabeza = nullptr;
    contador = 0;
}

Lista::~Lista() {
    while (!estaVacia()) {
        eliminarPrimero();
    }
}

bool Lista::estaVacia() {
    return (cabeza == nullptr);
}

bool Lista::estaLlena() {
    return false; // Memoria dinámica, se llena si se agota la RAM
}

// Inserción al final de la lista para mantener orden cronológico
void Lista::insertarAlFinal(int v) {
    Nodo* nuevo = new Nodo();
    nuevo->dato = v;
    nuevo->siguiente = nullptr;

    if (estaVacia()) {
        cabeza = nuevo;
    } else {
        Nodo* auxiliar = cabeza;
        while (auxiliar->siguiente != nullptr) {
            auxiliar = auxiliar->siguiente;
        }
        auxiliar->siguiente = nuevo;
    }
    contador++;
    cout << "\n[+] Elemento " << v << " insertado al final." << endl;
}

// Eliminación por el inicio de la lista
int Lista::eliminarPrimero() {
    if (estaVacia()) {
        cout << "\n[!] Error: Lista vacia." << endl;
        return -1;
    } else {
        Nodo* auxiliar = cabeza;
        int valor = auxiliar->dato;
        cabeza = cabeza->siguiente;
        delete auxiliar;
        contador--;
        return valor;
    }
}

void Lista::visualizar() {
    if (estaVacia()) {
        cout << "\nLa lista esta vacia." << endl;
    } else {
        cout << "\n--- ESTADO DE LA LISTA ---" << endl;
        Nodo* actual = cabeza;
        while (actual != nullptr) {
            cout << "[ " << actual->dato << " ] -> ";
            actual = actual->siguiente;
        }
        cout << "NULL\n--------------------------" << endl;
    }
}

int Lista::obtenerTamano() {
    return contador;
}

// =================================================================
// SERIALIZACIÓN / EXPORTACIÓN DE LA LISTA ENCADENADA
// =================================================================

void Lista::guardarTXT(const string& nombreArchivo) {
    ofstream archivo(nombreArchivo);
    if (archivo.is_open()) {
        archivo << "=== REPORTE DE LISTA ENLAZADA ===\n";
        archivo << "Elementos totales: " << contador << "\n\n";
        
        Nodo* actual = cabeza;
        int pos = 1;
        while (actual != nullptr) {
            archivo << "Nodo [" << pos << "] -> Valor: " << actual->dato;
            if (actual == cabeza) archivo << " (CABEZA)";
            archivo << "\n";
            actual = actual->siguiente;
            pos++;
        }
        archivo.close();
        cout << "[OK] Exportado a TXT." << endl;
    }
}

void Lista::guardarCSV(const string& nombreArchivo) {
    ofstream archivo(nombreArchivo);
    if (archivo.is_open()) {
        archivo << "Indice,Valor,EsCabeza\n";
        Nodo* actual = cabeza;
        int pos = 1;
        while (actual != nullptr) {
            archivo << pos << "," << actual->dato << "," << (actual == cabeza ? "true" : "false") << "\n";
            actual = actual->siguiente;
            pos++;
        }
        archivo.close();
        cout << "[OK] Exportado a CSV." << endl;
    }
}

void Lista::guardarXML(const string& nombreArchivo) {
    ofstream archivo(nombreArchivo);
    if (archivo.is_open()) {
        archivo << "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
        archivo << "<lista>\n";
        archivo << "    <metadata>\n";
        archivo << "        <total_nodos>" << contador << "</total_nodos>\n";
        archivo << "    </metadata>\n";
        archivo << "    <elementos>\n";
        
        Nodo* actual = cabeza;
        while (actual != nullptr) {
            archivo << "        <nodo>\n";
            archivo << "            <valor>" << actual->dato << "</valor>\n";
            archivo << "            <es_inicio>" << (actual == cabeza ? "true" : "false") << "</es_inicio>\n";
            archivo << "        </nodo>\n";
            actual = actual->siguiente;
        }
        archivo << "    </elementos>\n";
        archivo << "</lista>\n";
        archivo.close();
        cout << "[OK] Exportado a XML." << endl;
    }
}

void Lista::guardarJSON(const string& nombreArchivo) {
    ofstream archivo(nombreArchivo);
    if (archivo.is_open()) {
        archivo << "{\n";
        archivo << "  \"estructura\": \"lista_enlazada_simple\",\n";
        archivo << "  \"total\": " << contador << ",\n";
        archivo << "  \"nodos\": [\n";
        
        Nodo* actual = cabeza;
        while (actual != nullptr) {
            archivo << "    {\n";
            archivo << "      \"valor\": " << actual->dato << ",\n";
            archivo << "      \"cabeza\": " << (actual == cabeza ? true : false) << "\n";
            archivo << "    }";
            
            actual = actual->siguiente;
            if (actual != nullptr) archivo << ",\n";
            else archivo << "\n";
        }
        archivo << "  ]\n";
        archivo << "}\n";
        archivo.close();
        cout << "[OK] Exportado a JSON." << endl;
    }
}