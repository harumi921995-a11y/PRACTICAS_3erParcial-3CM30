#ifndef LISTA_H
#define LISTA_H

#include <string>

struct Nodo {
    int dato;           // Valor almacenado
    Nodo* siguiente;    // Enlace al siguiente nodo
};

class Lista {
private:
    Nodo* cabeza;       // Puntero al primer nodo de la lista
    int contador;       // Control del tamaño de la lista

public:
    Lista();            // Inicializa la lista vacía
    ~Lista();           // Libera la memoria de todos los nodos

    bool estaVacia();    
    bool estaLlena();    
    void insertarAlFinal(int v); // Operación de inserción secuencial
    int eliminarPrimero();       // Operación de extracción
    void visualizar();   
    int obtenerTamano(); 

    // Métodos de persistencia de datos / exportación
    void guardarTXT(const std::string& nombreArchivo);
    void guardarCSV(const std::string& nombreArchivo);
    void guardarXML(const std::string& nombreArchivo);
    void guardarJSON(const std::string& nombreArchivo);
};

#endif