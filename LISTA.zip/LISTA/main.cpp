#include <iostream>
#include <cstdlib>
#include "lista.h"

using namespace std;

int main() {
    Lista miLista;
    int opcion, valor;

    do {
        system("cls");
        cout << "=== MENU ESTRUCTURA DE DATOS: LISTA ===" << endl;
        cout << "1. Insertar nodo al final" << endl;
        cout << "2. Eliminar primer nodo" << endl;
        cout << "3. Visualizar lista completa" << endl;
        cout << "4. Verificar si esta vacia" << endl;
        cout << "5. Verificar si esta llena" << endl;
        cout << "6. Consultar longitud de la lista" << endl;
        cout << "7. Exportar estado actual a archivos" << endl;
        cout << "8. Salir del programa" << endl;
        cout << "=======================================" << endl;
        cout << "Selecciona una opcion: ";
        cin >> opcion;

        switch (opcion) {
            case 1:
                cout << "Ingresa el valor numericamente: ";
                cin >> valor;
                miLista.insertarAlFinal(valor);
                system("pause");
                break;

            case 2:
                valor = miLista.eliminarPrimero();
                if (valor != -1) cout << "\nNodo inicial extraido. Valor: " << valor << endl;
                system("pause");
                break;

            case 3:
                miLista.visualizar();
                system("pause");
                break;

            case 4:
                if (miLista.estaVacia()) cout << "\nEstado: Lista vacia." << endl;
                else cout << "\nEstado: La lista contiene nodos." << endl;
                system("pause");
                break;

            case 5:
                cout << "\nEstado: Memoria disponible en RAM de manera dinamica." << endl;
                system("pause");
                break;

            case 6:
                cout << "\nLongitud actual: " << miLista.obtenerTamano() << " nodos." << endl;
                system("pause");
                break;

            case 7:
                cout << "\nGenerando archivos de reporte..." << endl;
                miLista.guardarTXT("reporte_lista.txt");
                miLista.guardarCSV("reporte_lista.csv");
                miLista.guardarXML("reporte_lista.xml");
                miLista.guardarJSON("reporte_lista.json");
                system("pause");
                break;

            case 8:
                cout << "\nFinalizando ejecucion y liberando recursos..." << endl;
                break;

            default:
                cout << "\n[!] Opcion no disponible." << endl;
                system("pause");
        }
    } while (opcion != 8);

    return 0;
}