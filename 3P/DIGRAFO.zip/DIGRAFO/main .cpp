#include <iostream>
#include <vector>
#include <unordered_map>
#include <string>
#include <fstream>
#include <queue>
#include <limits>
#include <algorithm>
#include <functional>
#include <tuple>
#include "json.hpp"
#include "pugixml.hpp"
using json = nlohmann::json;
struct Arista {
    std::string destino;
    int peso;
};
class Digrafo {
private:
    std::unordered_map<std::string, std::vector<Arista>> listaAdyacencia;
    std::vector<std::string> ultimaRuta;
    int ultimaDistancia;
    std::string ultimoOrigen;
    std::string ultimoDestino;
    bool buscarRutaRecursiva(
        const std::string& actual,
        const std::string& destino,
        std::unordered_map<std::string, bool>& visitados,
        std::vector<std::string>& ruta
    ) const {
        visitados[actual] = true;
        ruta.push_back(actual);
        if (actual == destino) {
            return true;
        }
        std::unordered_map<
            std::string,
            std::vector<Arista>
        >::const_iterator it;
        it = listaAdyacencia.find(actual);
        if (it != listaAdyacencia.end()) {
            for (size_t i = 0; i < it->second.size(); i++) {
                const std::string& siguiente =
                    it->second[i].destino;
                if (!visitados[siguiente]) {
                    if (
                        buscarRutaRecursiva(
                            siguiente,
                            destino,
                            visitados,
                            ruta
                        )
                    ) {
                        return true;
                    }
                }
            }
        }
        ruta.pop_back();
        return false;
    }
    int obtenerPesoArista(
        const std::string& origen,
        const std::string& destino
    ) const {
        std::unordered_map<
            std::string,
            std::vector<Arista>
        >::const_iterator it;
        it = listaAdyacencia.find(origen);
        if (it == listaAdyacencia.end()) {
            return -1;
        }
        for (size_t i = 0; i < it->second.size(); i++) {
            if (it->second[i].destino == destino) {
                return it->second[i].peso;
            }
        }
        return -1;
    }
    void limpiarUltimaRuta() {
        ultimaRuta.clear();
        ultimaDistancia = -1;
        ultimoOrigen.clear();
        ultimoDestino.clear();
    }
public:
    Digrafo() {
        ultimaDistancia = -1;
    }
    bool existeNodo(const std::string& nodo) const {
        return listaAdyacencia.find(nodo)
            != listaAdyacencia.end();
    }
    void agregarNodo(const std::string& nodo) {
        if (nodo.empty()) {
            std::cout
                << "[X] El nombre del nodo no puede estar vacio.\n";
            return;
        }
        if (existeNodo(nodo)) {
            std::cout << "[X] El nodo ya existe.\n";
            return;
        }
        listaAdyacencia[nodo] =
            std::vector<Arista>();
        limpiarUltimaRuta();
        std::cout
            << "[+] Nodo agregado correctamente.\n";
    }
    bool existeArista(
        const std::string& origen,
        const std::string& destino
    ) const {
        std::unordered_map<
            std::string,
            std::vector<Arista>
        >::const_iterator it;
        it = listaAdyacencia.find(origen);
        if (it == listaAdyacencia.end()) {
            return false;
        }
        for (size_t i = 0; i < it->second.size(); i++) {
            if (it->second[i].destino == destino) {
                return true;
            }
        }
        return false;
    }
    bool agregarArista(
        const std::string& origen,
        const std::string& destino,
        int peso
    ) {
        if (peso < 0) {
            std::cout
                << "[X] No se permiten pesos negativos.\n";
            return false;
        }
        if (origen == destino) {
            std::cout
                << "[X] No se permite conectar un nodo consigo mismo.\n";
            return false;
        }
        if (!existeNodo(origen)) {
            listaAdyacencia[origen] =
                std::vector<Arista>();
        }
        if (!existeNodo(destino)) {
            listaAdyacencia[destino] =
                std::vector<Arista>();
        }
        if (existeArista(origen, destino)) {
            std::cout
                << "[X] La arista dirigida ya existe.\n";
            return false;
        }
        listaAdyacencia[origen].push_back({
            destino,
            peso
        });
        limpiarUltimaRuta();
        std::cout
            << "[+] Arista dirigida agregada correctamente.\n";
        return true;
    }
    bool agregarRuta(
        const std::vector<std::string>& nodosRuta,
        const std::vector<int>& pesos
    ) {
        if (nodosRuta.size() < 2) {
            std::cout
                << "[X] Una ruta necesita al menos dos nodos.\n";
            return false;
        }
        if (pesos.size() != nodosRuta.size() - 1) {
            std::cout
                << "[X] La cantidad de pesos no coincide con la ruta.\n";
            return false;
        }
        bool completa = true;
        for (
            size_t i = 0;
            i + 1 < nodosRuta.size();
            i++
        ) {
            if (
                !agregarArista(
                    nodosRuta[i],
                    nodosRuta[i + 1],
                    pesos[i]
                )
            ) {
                completa = false;
            }
        }
        if (completa) {
            std::cout
                << "[+] Ruta dirigida agregada correctamente.\n";
        } else {
            std::cout
                << "[!] La ruta se agrego parcialmente.\n";
        }
        return completa;
    }
    bool eliminarArista(
        const std::string& origen,
        const std::string& destino
    ) {
        if (
            !existeNodo(origen) ||
            !existeNodo(destino)
        ) {
            std::cout
                << "[X] Uno de los nodos no existe.\n";
            return false;
        }
        std::vector<Arista>& aristas =
            listaAdyacencia[origen];
        std::vector<Arista>::iterator nuevoFinal =
            std::remove_if(
                aristas.begin(),
                aristas.end(),
                [&](const Arista& arista) {
                    return arista.destino == destino;
                }
            );
        bool eliminada =
            nuevoFinal != aristas.end();
        aristas.erase(
            nuevoFinal,
            aristas.end()
        );
        limpiarUltimaRuta();
        if (eliminada) {
            std::cout
                << "[+] Arista dirigida eliminada correctamente.\n";
        } else {
            std::cout
                << "[X] La arista dirigida no existe.\n";
        }
        return eliminada;
    }
    bool eliminarNodo(const std::string& nodo) {
        if (!existeNodo(nodo)) {
            std::cout
                << "[X] El nodo no existe.\n";
            return false;
        }
        listaAdyacencia.erase(nodo);
        std::unordered_map<
            std::string,
            std::vector<Arista>
        >::iterator it;
        for (
            it = listaAdyacencia.begin();
            it != listaAdyacencia.end();
            ++it
        ) {
            std::vector<Arista>& aristas =
                it->second;
            aristas.erase(
                std::remove_if(
                    aristas.begin(),
                    aristas.end(),
                    [&](const Arista& arista) {
                        return arista.destino == nodo;
                    }
                ),
                aristas.end()
            );
        }
        limpiarUltimaRuta();
        std::cout
            << "[+] Nodo eliminado correctamente.\n";
        return true;
    }
    void mostrar() const {
        std::cout
            << "\n====================================\n";
        std::cout
            << " DIGRAFO DIRIGIDO\n";
        std::cout
            << "====================================\n";
        if (listaAdyacencia.empty()) {
            std::cout
                << "(El digrafo esta vacio)\n";
            return;
        }
        std::unordered_map<
            std::string,
            std::vector<Arista>
        >::const_iterator it;
        for (
            it = listaAdyacencia.begin();
            it != listaAdyacencia.end();
            ++it
        ) {
            std::cout
                << "Nodo ["
                << it->first
                << "]: ";
            if (it->second.empty()) {
                std::cout
                    << "(Sin conexiones salientes)";
            }
            for (size_t i = 0; i < it->second.size(); i++) {
                std::cout
                    << "-> "
                    << it->second[i].destino
                    << " (peso: "
                    << it->second[i].peso
                    << ") ";
            }
            std::cout << "\n";
        }
        if (!ultimaRuta.empty()) {
            std::cout
                << "\nNodo de origen: "
                << ultimoOrigen
                << "\n";
            std::cout
                << "Nodo de destino: "
                << ultimoDestino
                << "\n";
            std::cout
                << "Ultima ruta calculada: ";
            for (size_t i = 0; i < ultimaRuta.size(); i++) {
                std::cout << ultimaRuta[i];
                if (i + 1 < ultimaRuta.size()) {
                    std::cout << " -> ";
                }
            }
            std::cout
                << "\nDistancia total: "
                << ultimaDistancia
                << "\n";
        }
    }
    bool buscarRuta(
        const std::string& origen,
        const std::string& destino
    ) const {
        if (
            !existeNodo(origen) ||
            !existeNodo(destino)
        ) {
            std::cout
                << "[X] El nodo de origen o destino no existe.\n";
            return false;
        }
        std::unordered_map<std::string, bool>
            visitados;
        std::vector<std::string> ruta;
        bool encontrada =
            buscarRutaRecursiva(
                origen,
                destino,
                visitados,
                ruta
            );
        if (!encontrada) {
            std::cout
                << "[X] No existe una ruta dirigida entre "
                << origen
                << " y "
                << destino
                << ".\n";
            return false;
        }
        int pesoTotal = 0;
        std::cout
            << "\n====================================\n";
        std::cout
            << " RUTA DIRIGIDA ENCONTRADA\n";
        std::cout
            << "====================================\n";
        std::cout
            << "Nodo de origen: "
            << origen
            << "\n";
        std::cout
            << "Nodo de destino: "
            << destino
            << "\n\n";
        std::cout << "Aristas recorridas:\n";
        for (
            size_t i = 0;
            i + 1 < ruta.size();
            i++
        ) {
            int peso =
                obtenerPesoArista(
                    ruta[i],
                    ruta[i + 1]
                );
            if (peso >= 0) {
                pesoTotal += peso;
            }
            std::cout
                << ruta[i]
                << " -> "
                << ruta[i + 1]
                << " | peso: "
                << peso
                << "\n";
        }
        std::cout << "\nRuta completa: ";
        for (size_t i = 0; i < ruta.size(); i++) {
            std::cout << ruta[i];
            if (i + 1 < ruta.size()) {
                std::cout << " -> ";
            }
        }
        std::cout
            << "\nPeso total de la ruta: "
            << pesoTotal
            << "\n";
        return true;
    }
    bool dijkstra(
        const std::string& origen,
        const std::string& destino
    ) {
        limpiarUltimaRuta();
        ultimoOrigen = origen;
        ultimoDestino = destino;
        if (
            !existeNodo(origen) ||
            !existeNodo(destino)
        ) {
            std::cout
                << "[X] El nodo de origen o destino no existe.\n";
            limpiarUltimaRuta();
            return false;
        }
        const int infinito =
            std::numeric_limits<int>::max();
        std::unordered_map<std::string, int>
            distancias;
        std::unordered_map<
            std::string,
            std::string
        > anteriores;
        std::unordered_map<
            std::string,
            std::vector<Arista>
        >::const_iterator it;
        for (
            it = listaAdyacencia.begin();
            it != listaAdyacencia.end();
            ++it
        ) {
            distancias[it->first] = infinito;
        }
        typedef std::pair<
            int,
            std::string
        > ElementoCola;
        std::priority_queue<
            ElementoCola,
            std::vector<ElementoCola>,
            std::greater<ElementoCola>
        > cola;
        distancias[origen] = 0;
        cola.push(
            std::make_pair(
                0,
                origen
            )
        );
        while (!cola.empty()) {
            int distanciaActual =
                cola.top().first;
            std::string nodoActual =
                cola.top().second;
            cola.pop();
            if (
                distanciaActual >
                distancias[nodoActual]
            ) {
                continue;
            }
            if (nodoActual == destino) {
                break;
            }
            const std::vector<Arista>& vecinos =
                listaAdyacencia[nodoActual];
            for (size_t i = 0; i < vecinos.size(); i++) {
                int nuevaDistancia =
                    distanciaActual +
                    vecinos[i].peso;
                if (
                    nuevaDistancia <
                    distancias[vecinos[i].destino]
                ) {
                    distancias[vecinos[i].destino] =
                        nuevaDistancia;
                    anteriores[vecinos[i].destino] =
                        nodoActual;
                    cola.push(
                        std::make_pair(
                            nuevaDistancia,
                            vecinos[i].destino
                        )
                    );
                }
            }
        }
        if (distancias[destino] == infinito) {
            std::cout
                << "[X] No existe una ruta dirigida entre los nodos.\n";
            limpiarUltimaRuta();
            return false;
        }
        std::string actual = destino;
        while (actual != origen) {
            ultimaRuta.push_back(actual);
            actual =
                anteriores[actual];
        }
        ultimaRuta.push_back(origen);
        std::reverse(
            ultimaRuta.begin(),
            ultimaRuta.end()
        );
        ultimaDistancia =
            distancias[destino];
        std::cout
            << "\n[+] Nodo de origen: "
            << origen
            << "\n";
        std::cout
            << "[+] Nodo de destino: "
            << destino
            << "\n";
        std::cout
            << "[+] Ruta dirigida mas corta: ";
        for (size_t i = 0; i < ultimaRuta.size(); i++) {
            std::cout << ultimaRuta[i];
            if (i + 1 < ultimaRuta.size()) {
                std::cout << " -> ";
            }
        }
        std::cout
            << "\n[+] Distancia total: "
            << ultimaDistancia
            << "\n";
        return true;
    }
    std::vector<
        std::tuple<
            std::string,
            std::string,
            int
        >
    > obtenerAristas() const {
        std::vector<
            std::tuple<
                std::string,
                std::string,
                int
            >
        > resultado;
        std::unordered_map<
            std::string,
            std::vector<Arista>
        >::const_iterator it;
        for (
            it = listaAdyacencia.begin();
            it != listaAdyacencia.end();
            ++it
        ) {
            for (size_t i = 0; i < it->second.size(); i++) {
                resultado.push_back(
                    std::make_tuple(
                        it->first,
                        it->second[i].destino,
                        it->second[i].peso
                    )
                );
            }
        }
        return resultado;
    }
    bool cargarJSON(
        const std::string& rutaArchivo
    ) {
        std::ifstream archivo(
            rutaArchivo.c_str()
        );
        if (!archivo.is_open()) {
            std::cout
                << "[X] No se pudo abrir el archivo JSON.\n";
            return false;
        }
        try {
            json datos;
            archivo >> datos;
            if (
                !datos.contains("tipo") ||
                !datos.contains("nodos") ||
                !datos.contains("aristas")
            ) {
                std::cout
                    << "[X] Faltan tipo, nodos o aristas.\n";
                return false;
            }
            std::string tipo =
                datos["tipo"].get<std::string>();
            if (tipo != "dirigido") {
                std::cout
                    << "[X] El archivo no corresponde a un digrafo dirigido.\n";
                return false;
            }
            listaAdyacencia.clear();
            limpiarUltimaRuta();
            for (
                size_t i = 0;
                i < datos["nodos"].size();
                i++
            ) {
                std::string nodo =
                    datos["nodos"][i]
                    .get<std::string>();
                listaAdyacencia[nodo] =
                    std::vector<Arista>();
            }
            for (
                size_t i = 0;
                i < datos["aristas"].size();
                i++
            ) {
                std::string origen =
                    datos["aristas"][i]["origen"]
                    .get<std::string>();
                std::string destino =
                    datos["aristas"][i]["destino"]
                    .get<std::string>();
                int peso =
                    datos["aristas"][i]["peso"]
                    .get<int>();
                agregarArista(
                    origen,
                    destino,
                    peso
                );
            }
            if (
                datos.contains("dijkstra") &&
                !datos["dijkstra"].is_null()
            ) {
                json resultado =
                    datos["dijkstra"];
                if (resultado.contains("origen")) {
                    ultimoOrigen =
                        resultado["origen"]
                        .get<std::string>();
                }
                if (resultado.contains("destino")) {
                    ultimoDestino =
                        resultado["destino"]
                        .get<std::string>();
                }
                if (resultado.contains("distancia")) {
                    ultimaDistancia =
                        resultado["distancia"]
                        .get<int>();
                }
                if (resultado.contains("ruta")) {
                    ultimaRuta =
                        resultado["ruta"]
                        .get<
                            std::vector<std::string>
                        >();
                }
            }
            return true;
        }
        catch (const std::exception& error) {
            std::cout
                << "[X] Error JSON: "
                << error.what()
                << "\n";
            return false;
        }
    }
    bool cargarXML(
        const std::string& rutaArchivo
    ) {
        pugi::xml_document documento;
        pugi::xml_parse_result resultado =
            documento.load_file(
                rutaArchivo.c_str()
            );
        if (!resultado) {
            std::cout
                << "[X] No se pudo abrir o leer el XML.\n";
            return false;
        }
        pugi::xml_node raiz =
            documento.child("Digrafo");
        if (!raiz) {
            std::cout
                << "[X] No existe el elemento <Digrafo>.\n";
            return false;
        }
        std::string tipo =
            raiz.attribute("tipo").as_string();
        if (
            !tipo.empty() &&
            tipo != "dirigido"
        ) {
            std::cout
                << "[X] El XML no corresponde a un digrafo dirigido.\n";
            return false;
        }
        listaAdyacencia.clear();
        limpiarUltimaRuta();
        pugi::xml_node nodo;
        for (
            nodo =
                raiz.child("Nodos").child("Nodo");
            nodo;
            nodo = nodo.next_sibling("Nodo")
        ) {
            std::string id =
                nodo.attribute("id").as_string();
            if (!id.empty()) {
                listaAdyacencia[id] =
                    std::vector<Arista>();
            }
        }
        pugi::xml_node arista;
        for (
            arista =
                raiz.child("Aristas").child("Arista");
            arista;
            arista = arista.next_sibling("Arista")
        ) {
            agregarArista(
                arista.attribute("origen").as_string(),
                arista.attribute("destino").as_string(),
                arista.attribute("peso").as_int()
            );
        }
        pugi::xml_node resultadoDijkstra =
            raiz.child("Dijkstra");
        if (resultadoDijkstra) {
            ultimoOrigen =
                resultadoDijkstra
                .attribute("origen")
                .as_string();
            ultimoDestino =
                resultadoDijkstra
                .attribute("destino")
                .as_string();
            ultimaDistancia =
                resultadoDijkstra
                .attribute("distancia")
                .as_int(-1);
            pugi::xml_node paso;
            for (
                paso =
                    resultadoDijkstra.child("Paso");
                paso;
                paso = paso.next_sibling("Paso")
            ) {
                ultimaRuta.push_back(
                    paso.attribute("id")
                    .as_string()
                );
            }
        }
        return true;
    }
    bool guardarTXT() const {
        std::ofstream archivo("digrafo.txt");
        if (!archivo.is_open()) {
            return false;
        }
        archivo << "DIGRAFO DIRIGIDO\n\n";
        archivo << "NODOS:\n";
        std::unordered_map<
            std::string,
            std::vector<Arista>
        >::const_iterator it;
        for (
            it = listaAdyacencia.begin();
            it != listaAdyacencia.end();
            ++it
        ) {
            archivo << it->first << "\n";
        }
        archivo
            << "\nARISTAS DIRIGIDAS:\n";
        std::vector<
            std::tuple<
                std::string,
                std::string,
                int
            >
        > aristas = obtenerAristas();
        for (size_t i = 0; i < aristas.size(); i++) {
            archivo
                << std::get<0>(aristas[i])
                << " -> "
                << std::get<1>(aristas[i])
                << " | peso: "
                << std::get<2>(aristas[i])
                << "\n";
        }
        archivo << "\nDIJKSTRA:\n";
        if (ultimaRuta.empty()) {
            archivo << "No calculada\n";
        } else {
            archivo
                << "Origen: "
                << ultimoOrigen
                << "\n";
            archivo
                << "Destino: "
                << ultimoDestino
                << "\n";
            archivo << "Ruta: ";
            for (size_t i = 0; i < ultimaRuta.size(); i++) {
                archivo << ultimaRuta[i];
                if (i + 1 < ultimaRuta.size()) {
                    archivo << " -> ";
                }
            }
            archivo
                << "\nDistancia total: "
                << ultimaDistancia
                << "\n";
        }
        return true;
    }
    bool guardarCSV() const {
        std::ofstream archivo("digrafo.csv");
        if (!archivo.is_open()) {
            return false;
        }
        archivo
            << "origen,destino,peso\n";
        std::vector<
            std::tuple<
                std::string,
                std::string,
                int
            >
        > aristas = obtenerAristas();
        for (size_t i = 0; i < aristas.size(); i++) {
            archivo
                << std::get<0>(aristas[i])
                << ","
                << std::get<1>(aristas[i])
                << ","
                << std::get<2>(aristas[i])
                << "\n";
        }
        return true;
    }
    bool guardarJSON() const {
        json datos;
        datos["tipo"] = "dirigido";
        datos["nodos"] = json::array();
        datos["aristas"] = json::array();
        std::unordered_map<
            std::string,
            std::vector<Arista>
        >::const_iterator it;
        for (
            it = listaAdyacencia.begin();
            it != listaAdyacencia.end();
            ++it
        ) {
            datos["nodos"].push_back(
                it->first
            );
        }
        std::vector<
            std::tuple<
                std::string,
                std::string,
                int
            >
        > aristas = obtenerAristas();
        for (size_t i = 0; i < aristas.size(); i++) {
            datos["aristas"].push_back({
                {
                    "origen",
                    std::get<0>(aristas[i])
                },
                {
                    "destino",
                    std::get<1>(aristas[i])
                },
                {
                    "peso",
                    std::get<2>(aristas[i])
                }
            });
        }
        if (!ultimaRuta.empty()) {
            datos["nodoOrigen"] =
                ultimoOrigen;
            datos["nodoDestino"] =
                ultimoDestino;
            datos["dijkstra"] = {
                {
                    "origen",
                    ultimoOrigen
                },
                {
                    "destino",
                    ultimoDestino
                },
                {
                    "ruta",
                    ultimaRuta
                },
                {
                    "distancia",
                    ultimaDistancia
                }
            };
        } else {
            datos["nodoOrigen"] = nullptr;
            datos["nodoDestino"] = nullptr;
            datos["dijkstra"] = nullptr;
        }
        std::ofstream archivo(
            "digrafo.json"
        );
        if (!archivo.is_open()) {
            return false;
        }
        archivo << datos.dump(4);
        return true;
    }
    bool guardarXML() const {
        pugi::xml_document documento;
        pugi::xml_node declaracion =
            documento.prepend_child(
                pugi::node_declaration
            );
        declaracion.append_attribute("version") =
            "1.0";
        declaracion.append_attribute("encoding") =
            "UTF-8";
        pugi::xml_node raiz =
            documento.append_child("Digrafo");
        raiz.append_attribute("tipo") =
            "dirigido";
        if (!ultimaRuta.empty()) {
            pugi::xml_node nodoOrigen =
                raiz.append_child(
                    "NodoOrigen"
                );
            nodoOrigen.append_attribute("id") =
                ultimoOrigen.c_str();
            pugi::xml_node nodoDestino =
                raiz.append_child(
                    "NodoDestino"
                );
            nodoDestino.append_attribute("id") =
                ultimoDestino.c_str();
        }
        pugi::xml_node nodos =
            raiz.append_child("Nodos");
        std::unordered_map<
            std::string,
            std::vector<Arista>
        >::const_iterator it;
        for (
            it = listaAdyacencia.begin();
            it != listaAdyacencia.end();
            ++it
        ) {
            pugi::xml_node nodo =
                nodos.append_child("Nodo");
            nodo.append_attribute("id") =
                it->first.c_str();
        }
        pugi::xml_node aristasXML =
            raiz.append_child("Aristas");
        std::vector<
            std::tuple<
                std::string,
                std::string,
                int
            >
        > aristas = obtenerAristas();
        for (size_t i = 0; i < aristas.size(); i++) {
            pugi::xml_node arista =
                aristasXML.append_child(
                    "Arista"
                );
            arista.append_attribute("origen") =
                std::get<0>(aristas[i]).c_str();
            arista.append_attribute("destino") =
                std::get<1>(aristas[i]).c_str();
            arista.append_attribute("peso") =
                std::get<2>(aristas[i]);
        }
        if (!ultimaRuta.empty()) {
            pugi::xml_node resultado =
                raiz.append_child("Dijkstra");
            resultado.append_attribute("origen") =
                ultimoOrigen.c_str();
            resultado.append_attribute("destino") =
                ultimoDestino.c_str();
            resultado.append_attribute("distancia") =
                ultimaDistancia;
            for (size_t i = 0; i < ultimaRuta.size(); i++) {
                pugi::xml_node paso =
                    resultado.append_child(
                        "Paso"
                    );
                paso.append_attribute("id") =
                    ultimaRuta[i].c_str();
            }
        }
        return documento.save_file(
            "digrafo.xml",
            "  "
        );
    }
    void guardarCuatroFormatos() const {
        bool txt = guardarTXT();
        bool csv = guardarCSV();
        bool xml = guardarXML();
        bool jsonGuardado =
            guardarJSON();
        std::cout
            << "\n--- EXPORTACION ---\n";
        std::cout
            << "TXT: "
            << (txt ? "OK" : "ERROR")
            << "\n";
        std::cout
            << "CSV: "
            << (csv ? "OK" : "ERROR")
            << "\n";
        std::cout
            << "XML: "
            << (xml ? "OK" : "ERROR")
            << "\n";
        std::cout
            << "JSON: "
            << (jsonGuardado ? "OK" : "ERROR")
            << "\n";
    }
};
int main() {
    Digrafo digrafo;
    int opcionInicial;
    std::cout
        << "====================================\n";
    std::cout
        << " SISTEMA DE DIGRAFO DIRIGIDO\n";
    std::cout
        << "====================================\n";
    std::cout << "1. Cargar JSON\n";
    std::cout << "2. Cargar XML\n";
    std::cout << "3. Iniciar vacio\n";
    std::cout << "Opcion: ";
    std::cin >> opcionInicial;
    if (
        opcionInicial == 1 ||
        opcionInicial == 2
    ) {
        std::string nombreArchivo;
        std::cout
            << "Nombre o ruta del archivo: ";
        std::cin >> nombreArchivo;
        bool cargado = false;
        if (opcionInicial == 1) {
            cargado =
                digrafo.cargarJSON(
                    nombreArchivo
                );
        } else {
            cargado =
                digrafo.cargarXML(
                    nombreArchivo
                );
        }
        if (!cargado) {
            std::cout
                << "[X] No se pudo cargar el archivo.\n";
            return 1;
        }
        std::cout
            << "[+] Archivo cargado correctamente.\n";
    }
    else if (opcionInicial != 3) {
        std::cout
            << "[X] Opcion invalida.\n";
        return 1;
    }
    int opcion;
    do {
        std::cout
            << "\n====================================\n";
        std::cout
            << " MENU DEL DIGRAFO\n";
        std::cout
            << "====================================\n";
        std::cout << "1. Ver digrafo\n";
        std::cout << "2. Agregar nodo\n";
        std::cout << "3. Agregar arista dirigida\n";
        std::cout << "4. Agregar ruta dirigida\n";
        std::cout << "5. Eliminar nodo\n";
        std::cout << "6. Eliminar arista dirigida\n";
        std::cout << "7. Buscar ruta dirigida\n";
        std::cout << "8. Ruta mas corta con Dijkstra\n";
        std::cout << "9. Guardar TXT, CSV, XML y JSON\n";
        std::cout << "10. Salir\n";
        std::cout << "Opcion: ";
        std::cin >> opcion;
        if (opcion == 1) {
            digrafo.mostrar();
        }
        else if (opcion == 2) {
            std::string nodo;
            std::cout
                << "Nombre del nodo: ";
            std::cin >> nodo;
            digrafo.agregarNodo(nodo);
        }
        else if (opcion == 3) {
            std::string origen;
            std::string destino;
            int peso;
            std::cout << "Nodo origen: ";
            std::cin >> origen;
            std::cout << "Nodo destino: ";
            std::cin >> destino;
            std::cout << "Peso: ";
            std::cin >> peso;
            digrafo.agregarArista(
                origen,
                destino,
                peso
            );
        }
        else if (opcion == 4) {
            int cantidadNodos;
            std::cout
                << "Cantidad de nodos de la ruta: ";
            std::cin >> cantidadNodos;
            if (cantidadNodos < 2) {
                std::cout
                    << "[X] La ruta necesita al menos dos nodos.\n";
            } else {
                std::vector<std::string>
                    nodosRuta(cantidadNodos);
                std::vector<int>
                    pesos(cantidadNodos - 1);
                for (
                    int i = 0;
                    i < cantidadNodos;
                    i++
                ) {
                    std::cout
                        << "Nodo "
                        << i + 1
                        << ": ";
                    std::cin
                        >> nodosRuta[i];
                }
                for (
                    int i = 0;
                    i < cantidadNodos - 1;
                    i++
                ) {
                    std::cout
                        << "Peso de "
                        << nodosRuta[i]
                        << " a "
                        << nodosRuta[i + 1]
                        << ": ";
                    std::cin
                        >> pesos[i];
                }
                digrafo.agregarRuta(
                    nodosRuta,
                    pesos
                );
            }
        }
        else if (opcion == 5) {
            std::string nodo;
            std::cout
                << "Nodo a eliminar: ";
            std::cin >> nodo;
            digrafo.eliminarNodo(nodo);
        }
        else if (opcion == 6) {
            std::string origen;
            std::string destino;
            std::cout << "Nodo origen: ";
            std::cin >> origen;
            std::cout << "Nodo destino: ";
            std::cin >> destino;
            digrafo.eliminarArista(
                origen,
                destino
            );
        }
        else if (opcion == 7) {
            std::string origen;
            std::string destino;
            std::cout
                << "Nodo de origen: ";
            std::cin >> origen;
            std::cout
                << "Nodo de destino: ";
            std::cin >> destino;
            digrafo.buscarRuta(
                origen,
                destino
            );
        }
        else if (opcion == 8) {
            std::string origen;
            std::string destino;
            std::cout
                << "Nodo inicial: ";
            std::cin >> origen;
            std::cout
                << "Nodo final: ";
            std::cin >> destino;
            digrafo.dijkstra(
                origen,
                destino
            );
        }
        else if (opcion == 9) {
            digrafo.guardarCuatroFormatos();
        }
        else if (opcion == 10) {
            digrafo.guardarCuatroFormatos();
            std::cout
                << "Programa cerrado.\n";
        }
        else {
            std::cout
                << "[X] Opcion invalida.\n";
        }
    } while (opcion != 10);
    return 0;
}