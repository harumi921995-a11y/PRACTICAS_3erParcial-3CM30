#include <iostream>
#include <string>
#include <vector>
#include <fstream>

#include "json.hpp"
#include "pugixml.hpp"

using json = nlohmann::json;

struct Nodo {
    int valor;
    Nodo* izquierdo;
    Nodo* derecho;

    Nodo(int v) {
        valor = v;
        izquierdo = nullptr;
        derecho = nullptr;
    }
};

class ArbolBinarioBusqueda {
private:
    Nodo* raiz;

    Nodo* insertarRec(Nodo* nodo, int valor) {
        if (nodo == nullptr) {
            return new Nodo(valor);
        }

        if (valor < nodo->valor) {
            nodo->izquierdo = insertarRec(nodo->izquierdo, valor);
        }
        else if (valor > nodo->valor) {
            nodo->derecho = insertarRec(nodo->derecho, valor);
        }
        else {
            std::cout << "[X] El valor ya existe en el arbol.\n";
        }

        return nodo;
    }

    bool buscarRec(Nodo* nodo, int valor) const {
        if (nodo == nullptr) {
            return false;
        }

        if (valor == nodo->valor) {
            return true;
        }

        if (valor < nodo->valor) {
            return buscarRec(nodo->izquierdo, valor);
        }

        return buscarRec(nodo->derecho, valor);
    }

    Nodo* encontrarMinimo(Nodo* nodo) {
        Nodo* actual = nodo;

        while (actual != nullptr && actual->izquierdo != nullptr) {
            actual = actual->izquierdo;
        }

        return actual;
    }

    Nodo* eliminarRec(Nodo* nodo, int valor) {
        if (nodo == nullptr) {
            return nullptr;
        }

        if (valor < nodo->valor) {
            nodo->izquierdo = eliminarRec(nodo->izquierdo, valor);
        }
        else if (valor > nodo->valor) {
            nodo->derecho = eliminarRec(nodo->derecho, valor);
        }
        else {
            if (nodo->izquierdo == nullptr) {
                Nodo* temporal = nodo->derecho;
                delete nodo;
                return temporal;
            }

            if (nodo->derecho == nullptr) {
                Nodo* temporal = nodo->izquierdo;
                delete nodo;
                return temporal;
            }

            Nodo* sucesor = encontrarMinimo(nodo->derecho);
            nodo->valor = sucesor->valor;
            nodo->derecho = eliminarRec(
                nodo->derecho,
                sucesor->valor
            );
        }

        return nodo;
    }

    void preordenRec(
        Nodo* nodo,
        std::vector<int>& resultado
    ) const {
        if (nodo == nullptr) {
            return;
        }

        resultado.push_back(nodo->valor);
        preordenRec(nodo->izquierdo, resultado);
        preordenRec(nodo->derecho, resultado);
    }

    void inordenRec(
        Nodo* nodo,
        std::vector<int>& resultado
    ) const {
        if (nodo == nullptr) {
            return;
        }

        inordenRec(nodo->izquierdo, resultado);
        resultado.push_back(nodo->valor);
        inordenRec(nodo->derecho, resultado);
    }

    void postordenRec(
        Nodo* nodo,
        std::vector<int>& resultado
    ) const {
        if (nodo == nullptr) {
            return;
        }

        postordenRec(nodo->izquierdo, resultado);
        postordenRec(nodo->derecho, resultado);
        resultado.push_back(nodo->valor);
    }

    void liberarMemoria(Nodo* nodo) {
        if (nodo == nullptr) {
            return;
        }

        liberarMemoria(nodo->izquierdo);
        liberarMemoria(nodo->derecho);

        delete nodo;
    }

public:
    ArbolBinarioBusqueda() {
        raiz = nullptr;
    }

    ~ArbolBinarioBusqueda() {
        liberarMemoria(raiz);
    }

    void insertar(int valor) {
        raiz = insertarRec(raiz, valor);
    }

    bool buscar(int valor) const {
        return buscarRec(raiz, valor);
    }

    bool eliminar(int valor) {
        if (!buscar(valor)) {
            return false;
        }

        raiz = eliminarRec(raiz, valor);
        return true;
    }

    std::vector<int> obtenerPreorden() const {
        std::vector<int> resultado;
        preordenRec(raiz, resultado);
        return resultado;
    }

    std::vector<int> obtenerInorden() const {
        std::vector<int> resultado;
        inordenRec(raiz, resultado);
        return resultado;
    }

    std::vector<int> obtenerPostorden() const {
        std::vector<int> resultado;
        postordenRec(raiz, resultado);
        return resultado;
    }

    void mostrarRecorridos() const {
        std::vector<int> preorden = obtenerPreorden();
        std::vector<int> inorden = obtenerInorden();
        std::vector<int> postorden = obtenerPostorden();

        std::cout << "\n--- RECORRIDOS DEL ARBOL ---\n";

        std::cout << "Preorden: ";
        for (int valor : preorden) {
            std::cout << valor << " ";
        }

        std::cout << "\nInorden: ";
        for (int valor : inorden) {
            std::cout << valor << " ";
        }

        std::cout << "\nPostorden: ";
        for (int valor : postorden) {
            std::cout << valor << " ";
        }

        std::cout << "\n";
    }

    bool cargarDesdeJSON(const std::string& rutaArchivo) {
        std::ifstream archivo(rutaArchivo);

        if (!archivo.is_open()) {
            return false;
        }

        try {
            json datos;
            archivo >> datos;

            if (!datos.contains("valores")) {
                std::cout
                    << "[X] El JSON debe contener el campo \"valores\".\n";

                return false;
            }

            for (const auto& valor : datos["valores"]) {
                insertar(valor.get<int>());
            }

            return true;
        }
        catch (const std::exception& error) {
            std::cout
                << "[X] Error de formato JSON: "
                << error.what()
                << "\n";

            return false;
        }
    }

    bool cargarDesdeXML(const std::string& rutaArchivo) {
        pugi::xml_document documento;

        pugi::xml_parse_result resultado =
            documento.load_file(rutaArchivo.c_str());

        if (!resultado) {
            return false;
        }

        pugi::xml_node raizXML = documento.child("Arbol");

        if (!raizXML) {
            std::cout
                << "[X] No existe el nodo raiz <Arbol>.\n";

            return false;
        }

        pugi::xml_node valoresXML =
            raizXML.child("Valores");

        for (
            pugi::xml_node nodo :
            valoresXML.children("Valor")
        ) {
            insertar(
                nodo.attribute("numero").as_int()
            );
        }

        return true;
    }

    bool guardarTXT() const {
        std::ofstream archivo("arbol.txt");

        if (!archivo.is_open()) {
            return false;
        }

        std::vector<int> preorden = obtenerPreorden();
        std::vector<int> inorden = obtenerInorden();
        std::vector<int> postorden = obtenerPostorden();

        archivo << "ARBOL BINARIO DE BUSQUEDA\n\n";

        archivo << "PREORDEN:\n";
        for (int valor : preorden) {
            archivo << valor << " ";
        }

        archivo << "\n\nINORDEN:\n";
        for (int valor : inorden) {
            archivo << valor << " ";
        }

        archivo << "\n\nPOSTORDEN:\n";
        for (int valor : postorden) {
            archivo << valor << " ";
        }

        archivo << "\n";

        return true;
    }

    bool guardarCSV() const {
        std::ofstream archivo("arbol.csv");

        if (!archivo.is_open()) {
            return false;
        }

        std::vector<int> preorden = obtenerPreorden();
        std::vector<int> inorden = obtenerInorden();
        std::vector<int> postorden = obtenerPostorden();

        archivo << "recorrido,valores\n";

        archivo << "preorden,\"";
        for (int valor : preorden) {
            archivo << valor << " ";
        }
        archivo << "\"\n";

        archivo << "inorden,\"";
        for (int valor : inorden) {
            archivo << valor << " ";
        }
        archivo << "\"\n";

        archivo << "postorden,\"";
        for (int valor : postorden) {
            archivo << valor << " ";
        }
        archivo << "\"\n";

        return true;
    }

    bool guardarJSON() const {
        json datos;

        datos["tipo"] = "arbol_binario_busqueda";
        datos["preorden"] = obtenerPreorden();
        datos["inorden"] = obtenerInorden();
        datos["postorden"] = obtenerPostorden();

        std::ofstream archivo("arbol.json");

        if (!archivo.is_open()) {
            return false;
        }

        archivo << datos.dump(4);

        return true;
    }

    bool guardarXML() const {
        pugi::xml_document documento;

        pugi::xml_node declaracion =
            documento.prepend_child(
                pugi::node_declaration
            );

        declaracion.append_attribute("version") = "1.0";
        declaracion.append_attribute("encoding") = "UTF-8";

        pugi::xml_node raizXML =
            documento.append_child("Arbol");

        std::vector<int> preorden = obtenerPreorden();
        std::vector<int> inorden = obtenerInorden();
        std::vector<int> postorden = obtenerPostorden();

        pugi::xml_node preordenXML =
            raizXML.append_child("Preorden");

        for (int valor : preorden) {
            pugi::xml_node nodo =
                preordenXML.append_child("Valor");

            nodo.append_attribute("numero") = valor;
        }

        pugi::xml_node inordenXML =
            raizXML.append_child("Inorden");

        for (int valor : inorden) {
            pugi::xml_node nodo =
                inordenXML.append_child("Valor");

            nodo.append_attribute("numero") = valor;
        }

        pugi::xml_node postordenXML =
            raizXML.append_child("Postorden");

        for (int valor : postorden) {
            pugi::xml_node nodo =
                postordenXML.append_child("Valor");

            nodo.append_attribute("numero") = valor;
        }

        return documento.save_file(
            "arbol.xml",
            "  "
        );
    }

    void guardarCuatroFormatos() const {
        bool txt = guardarTXT();
        bool csv = guardarCSV();
        bool xml = guardarXML();
        bool jsonGuardado = guardarJSON();

        std::cout << "\n--- EXPORTACION ---\n";
        std::cout
            << "TXT: "
            << (txt ? "OK" : "ERROR")
            << "\n";

        std::cout
            << "CSV: "
            << (csv ? "OK" : "ERROR")
            << "\n";

        std::cout
            << "XML: "
            << (xml ? "OK" : "ERROR")
            << "\n";

        std::cout
            << "JSON: "
            << (jsonGuardado ? "OK" : "ERROR")
            << "\n";

        if (txt && csv && xml && jsonGuardado) {
            std::cout
                << "[+] Se generaron arbol.txt, arbol.csv, "
                << "arbol.xml y arbol.json.\n";
        }
    }
};

int main() {
    ArbolBinarioBusqueda arbol;

    int opcionInicial;

    std::cout << "====================================\n";
    std::cout << " ARBOL BINARIO DE BUSQUEDA\n";
    std::cout << "====================================\n";

    std::cout << "1. Cargar desde JSON\n";
    std::cout << "2. Cargar desde XML\n";
    std::cout << "3. Iniciar arbol vacio\n";
    std::cout << "Opcion: ";
    std::cin >> opcionInicial;

    if (opcionInicial == 1 || opcionInicial == 2) {
        std::string nombreArchivo;

        std::cout << "Nombre o ruta del archivo: ";
        std::cin >> nombreArchivo;

        bool cargado = false;

        if (opcionInicial == 1) {
            cargado =
                arbol.cargarDesdeJSON(nombreArchivo);
        }
        else {
            cargado =
                arbol.cargarDesdeXML(nombreArchivo);
        }

        if (!cargado) {
            std::cout
                << "[X] No se pudo cargar el archivo.\n";

            return 1;
        }

        std::cout
            << "[+] Archivo cargado correctamente.\n";
    }

    int opcion;

    do {
        std::cout << "\n====================================\n";
        std::cout << " MENU DEL ARBOL\n";
        std::cout << "====================================\n";

        std::cout << "1. Insertar nodo\n";
        std::cout << "2. Buscar nodo\n";
        std::cout << "3. Eliminar nodo\n";
        std::cout << "4. Mostrar recorridos\n";
        std::cout << "5. Guardar TXT, CSV, XML y JSON\n";
        std::cout << "6. Salir\n";
        std::cout << "Opcion: ";
        std::cin >> opcion;

        if (opcion == 1) {
            int valor;

            std::cout << "Valor del nuevo nodo: ";
            std::cin >> valor;

            arbol.insertar(valor);

            std::cout << "[+] Operacion terminada.\n";
        }
        else if (opcion == 2) {
            int valor;

            std::cout << "Valor a buscar: ";
            std::cin >> valor;

            if (arbol.buscar(valor)) {
                std::cout
                    << "[+] El nodo existe en el arbol.\n";
            }
            else {
                std::cout
                    << "[X] El nodo no existe.\n";
            }
        }
        else if (opcion == 3) {
            int valor;

            std::cout << "Valor a eliminar: ";
            std::cin >> valor;

            if (arbol.eliminar(valor)) {
                std::cout
                    << "[+] Nodo eliminado correctamente.\n";
            }
            else {
                std::cout
                    << "[X] El nodo no existe.\n";
            }
        }
        else if (opcion == 4) {
            arbol.mostrarRecorridos();
        }
        else if (opcion == 5) {
            arbol.guardarCuatroFormatos();
        }
        else if (opcion == 6) {
            arbol.guardarCuatroFormatos();

            std::cout << "\nPrograma cerrado.\n";
        }
        else {
            std::cout << "[X] Opcion no valida.\n";
        }

    } while (opcion != 6);

    return 0;
}