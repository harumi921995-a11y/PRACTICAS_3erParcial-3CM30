#ifndef PILA_H
#define PILA_H

#include <string>

struct Nodo {
    int dato;           // El valor que guardamos
    Nodo* siguiente;    // Puntero 
};

class Pila {
private:
    Nodo* tope;         // Puntero que siempre mira al elemento de arriba
    int contador;       // Para saber cuantos elementos hay sin tener que contar

public:
    Pila();             // Constructor: Inicia la pila vacia
    ~Pila();            // Destructor: Borra todo para no dejar basura en memoria
    
    bool estaVacia();    // Opcion 4
    bool estaLlena();    // Opcion 5 (En dinamica siempre es falso hasta agotar RAM)
    void agregar(int v); // Opcion 1 (Push)
    int quitar();        // Opcion 2 (Pop)
    void visualizar();   // Opcion 3
    int obtenerTamano(); // Opcion 6

    // ---- NUEVAS OPCIONES DE GUARDADO ----
    void guardarTXT(const std::string& nombreArchivo);
    void guardarCSV(const std::string& nombreArchivo);
    void guardarXML(const std::string& nombreArchivo);
    void guardarJSON(const std::string& nombreArchivo);
};

#endif