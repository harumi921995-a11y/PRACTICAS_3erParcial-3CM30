#include "PILA.h"
#include <iostream>
#include <fstream>

using namespace std;

// Al inicio no hay nodos, el tope apunta a la nada
Pila::Pila() {
    tope = nullptr;
    contador = 0;
}

// El destructor limpia la memoria al cerrar el programa
Pila::~Pila() {
    while (!estaVacia()) {
        quitar();
    }
}

bool Pila::estaVacia() {
    return (tope == nullptr);
}

// En una pila dinamica, la pila solo se llena si se acaba la memoria RAM
bool Pila::estaLlena() {
    return false; 
}

// 1. AGREGAR (Push)
void Pila::agregar(int v) {
    Nodo* nuevo = new Nodo(); // Creamos una nuevo  en la  memoria
    nuevo->dato = v;          // Le ponemos el valor
    nuevo->siguiente = tope;  // El nuevo nodo se pone encima del anterior tope
    tope = nuevo;             // Ahora el nuevo nodo es el que manda arriba
    contador++;
    cout << "\n[+] Elemento " << v << " apilado correctamente." << endl;
}

// 2. QUITAR (Pop)
int Pila::quitar() {
    if (estaVacia()) {
        cout << "\n[!] Error: Pila vacia." << endl;
        return -1;
    } else {
        Nodo* auxiliar = tope;    // Guardamos el nodo para no perderlo
        int valor = auxiliar->dato; // Guardamos el numero antes de borrar
        tope = tope->siguiente;   // El tope ahora es el que estaba abajo
        delete auxiliar;          // Borramos la cajita vieja de la memoria
        contador--;
        return valor;
    }
}

// 3. VISUALIZAR
void Pila::visualizar() {
    if (estaVacia()) {
        cout << "\nLa pila esta vacia." << endl;
    } else {
        cout << "\n--- PILA DINAMICA ACTUAL ---" << endl;
        Nodo* actual = tope;
        while (actual != nullptr) { // Recorremos de arriba a abajo
            cout << "|   " << actual->dato << "   |" << endl;
            actual = actual->siguiente;
        }
        cout << "-------------" << endl;
    }
}

int Pila::obtenerTamano() {
    return contador;
}

// =================================================================
// NUEVOS METODOS DE GUARDADO
// =================================================================

void Pila::guardarTXT(const string& nombreArchivo) {
    ofstream archivo(nombreArchivo);
    if (archivo.is_open()) {
        archivo << "=== ESTADO ACTUAL DE LA PILA ===\n";
        archivo << "Total de elementos: " << contador << "\n\n";
        
        Nodo* actual = tope;
        int posicion = 1;
        while (actual != nullptr) {
            archivo << "Posicion [" << posicion << "] -> Valor: " << actual->dato;
            if (actual == tope) archivo << " (TOPE)";
            archivo << "\n";
            actual = actual->siguiente;
            posicion++;
        }
        archivo.close();
        cout << "[OK] Archivo TXT creado correctamente." << endl;
    } else {
        cout << "[ERROR] No se pudo crear el archivo TXT." << endl;
    }
}

void Pila::guardarCSV(const string& nombreArchivo) {
    ofstream archivo(nombreArchivo);
    if (archivo.is_open()) {
        archivo << "Posicion,Valor,EsTope\n";
        Nodo* actual = tope;
        int posicion = 1;
        while (actual != nullptr) {
            archivo << posicion << "," << actual->dato << "," << (actual == tope ? "SI" : "NO") << "\n";
            actual = actual->siguiente;
            posicion++;
        }
        archivo.close();
        cout << "[OK] Archivo CSV creado correctamente." << endl;
    } else {
        cout << "[ERROR] No se pudo crear el archivo CSV." << endl;
    }
}

void Pila::guardarXML(const string& nombreArchivo) {
    ofstream archivo(nombreArchivo);
    if (archivo.is_open()) {
        archivo << "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
        archivo << "<pila>\n";
        archivo << "    <tamano>" << contador << "</tamano>\n";
        archivo << "    <elementos>\n";
        
        Nodo* actual = tope;
        while (actual != nullptr) {
            archivo << "        <nodo>\n";
            archivo << "            <valor>" << actual->dato << "</valor>\n";
            archivo << "            <es_tope>" << (actual == tope ? "true" : "false") << "</es_tope>\n";
            archivo << "        </nodo>\n";
            actual = actual->siguiente;
        }
        archivo << "    </elementos>\n";
        archivo << "</pila>\n";
        archivo.close();
        cout << "[OK] Archivo XML creado correctamente." << endl;
    } else {
        cout << "[ERROR] No se pudo crear el archivo XML." << endl;
    }
}

void Pila::guardarJSON(const string& nombreArchivo) {
    ofstream archivo(nombreArchivo);
    if (archivo.is_open()) {
        archivo << "{\n";
        archivo << "  \"tamano\": " << contador << ",\n";
        archivo << "  \"elementos\": [\n";
        
        Nodo* actual = tope;
        while (actual != nullptr) {
            archivo << "    {\n";
            archivo << "      \"valor\": " << actual->dato << ",\n";
            archivo << "      \"es_tope\": " << (actual == tope ? "true" : "false") << "\n";
            archivo << "    }";
            
            actual = actual->siguiente;
            if (actual != nullptr) archivo << ",\n"; // Coma JSON si no es el último
            else archivo << "\n";
        }
        archivo << "  ]\n";
        archivo << "}\n";
        archivo.close();
        cout << "[OK] Archivo JSON creado correctamente." << endl;
    } else {
        cout << "[ERROR] No se pudo crear el archivo JSON." << endl;
    }
}