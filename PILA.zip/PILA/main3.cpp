#include <iostream>
#include <cstdlib>
#include "PILA.h"

using namespace std;

int main() {
    Pila p;
    int opcion, valor;

    do {
        system("cls"); // Limpia la pantalla cada vez (en Windows)
        
        cout << "--- PILA DINAMICA INTERACTIVA ---" << endl;
        cout << "1. Agregar elemento (Push)" << endl;
        cout << "2. Quitar elemento (Pop)" << endl;
        cout << "3. Mostrar pila" << endl;
        cout << "4. Verificar si esta vacia" << endl;
        cout << "5. Verificar si esta llena" << endl;
        cout << "6. Mostrar tamano de la pila" << endl;
        cout << "7. Guardar en archivos (TXT, CSV, XML, JSON)" << endl;
        cout << "8. Salir" << endl;
        cout << "-----------------------------------" << endl;
        cout << "Elige una opcion: ";
        cin >> opcion;

        switch (opcion) {
            case 1:
                cout << "Escribe el numero a apilar: ";
                cin >> valor;
                p.agregar(valor);
                system("pause");
                break;

            case 2:
                valor = p.quitar();
                if (valor != -1) cout << "\nQuitaste el valor: " << valor << endl;
                system("pause");
                break;

            case 3:
                p.visualizar();
                system("pause");
                break;

            case 4:
                if (p.estaVacia()) cout << "\nConfirmado: La pila esta vacia." << endl;
                else cout << "\nLa pila tiene nodos enlazados." << endl;
                system("pause");
                break;

            case 5:
                cout << "\nLa pila dinamica no esta llena (tiene RAM libre)." << endl;
                system("pause");
                break;

            case 6:
                cout << "\nHay " << p.obtenerTamano() << " nodos creados." << endl;
                system("pause");
                break;

            case 7:
                cout << "\n--- Exportando el estado actual de la pila ---" << endl;
                p.guardarTXT("pila_reporte.txt");
                p.guardarCSV("pila_reporte.csv");
                p.guardarXML("pila_reporte.xml");
                p.guardarJSON("pila_reporte.json");
                system("pause");
                break;

            case 8:
                cout << "\nSaliendo y liberando memoria de la pila..." << endl;
                break;

            default:
                cout << "\nOpcion no valida." << endl;
                system("pause");
        }
    } while (opcion != 8);

    return 0;
}